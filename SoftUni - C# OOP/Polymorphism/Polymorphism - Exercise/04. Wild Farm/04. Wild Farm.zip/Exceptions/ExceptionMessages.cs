﻿namespace P04.WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string FoodNotPreferred = "{0} does not eat {1}!";
    }
}
