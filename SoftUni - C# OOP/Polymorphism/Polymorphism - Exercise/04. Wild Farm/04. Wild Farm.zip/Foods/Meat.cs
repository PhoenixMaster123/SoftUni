﻿namespace P04.WildFarm.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {

        }
    }
}
