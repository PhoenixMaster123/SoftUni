﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {
        private string firstName;
        private string lastName;
        private int age;
        private decimal salary;
        public string FirstName
        {
            get
            {
                return this.firstName;
            }
            private set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("First name cannot contain fewer than 3 symbols!");
                }
                this.firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return this.lastName;
            }
            private set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Last name cannot contain fewer than 3 symbols!");
                }
                this.lastName = value;
            }
        }
        public int Age
        {
            get
            {
                return this.age;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Age cannot be zero or a negative integer!");
                }
                this.age = value;
            }
        }
        public decimal Salary
        {
            get
            {
                return this.salary;
            }
            private set
            {
                if (value < 650m)
                {
                    throw new ArgumentException("Salary cannot be less than 650 leva!");
                }
                this.salary = value;
               
            }
        }
    


        public Person(string firstName, string lastName, int age, decimal salary)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            this.Salary = salary;
        }

        public void IncreaseSalary(decimal percentage)
        {
            if (this.Age >= 30)
            {
                this.Salary += this.Salary * percentage / 100;
            }
            else
            {
                this.Salary += this.Salary * percentage / 200;
            }
        }
        public override string ToString()
        {
            return $"{this.FirstName} {this.LastName} receives {this.Salary:F2} leva.";
        }

    }
}
//namespace PersonsInfo
//{
//    using System;
//    public class Person
//    {
//        private string firstName;
//        private string lastName;
//        private int age;
//        private decimal salary;

//        public Person(string firstName, string lastName, int age, decimal salary)
//        {
//            if (firstName.Length >= 3)
//            {
//                this.firstName = firstName;

//            }
//            else throw new ArgumentException("First name cannot contain fewer than 3 symbols!");

//            if (lastName.Length >= 3)
//            {
//                this.lastName = lastName;
//            }
//            else throw new ArgumentException("Last name cannot contain fewer than 3 symbols!");

//            if (age > 0)
//            {
//                this.age = age;
//            }
//            else throw new ArgumentException("Age cannot be zero or a negative integer!");

//            if (salary > 460.0m)
//            {
//                this.salary = salary;
//            }
//            else throw new ArgumentException("Salary cannot be less than 460 leva!");
//        }

//        public int Age
//        {
//            get
//            {
//                return this.age;
//            }
//        }

//        public override string ToString()
//        {
//            return $"{this.firstName} {this.lastName} receives {this.salary:F2} leva.";
//        }

//        public void IncreaseSalary(decimal bonus)
//        {
//            if (this.age >= 30)
//            {
//                this.salary += this.salary * bonus / 100;
//            }
//            else
//            {
//                this.salary += this.salary * bonus / 200;
//            }
//        }
//    }
//}