﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface ICitizens
    {
        string Name { get; }

        int Age { get; }
    }

}
