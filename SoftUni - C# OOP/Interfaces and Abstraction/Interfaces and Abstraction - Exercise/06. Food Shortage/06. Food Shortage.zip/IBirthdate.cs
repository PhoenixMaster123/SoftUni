﻿namespace FoodShortage
{
    public interface IBirthdate
    {
        public string Birthday { get; }
    }
}
