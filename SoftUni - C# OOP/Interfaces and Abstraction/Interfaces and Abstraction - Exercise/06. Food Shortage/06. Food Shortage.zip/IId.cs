﻿namespace FoodShortage
{
    public interface IId
    {
        public string Id { get; set; }
    }
}
