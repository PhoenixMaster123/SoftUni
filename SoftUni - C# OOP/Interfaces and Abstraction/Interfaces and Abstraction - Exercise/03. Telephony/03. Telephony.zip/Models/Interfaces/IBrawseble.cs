﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Telephony.Models.Interfaces
{
    public interface IBrawseble
    {
        string BrawsURL(string url);
    }
}
