﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Telephony.Models.Interfaces
{
    public interface ICallable
    {
        string Call(string number);
    }
}
