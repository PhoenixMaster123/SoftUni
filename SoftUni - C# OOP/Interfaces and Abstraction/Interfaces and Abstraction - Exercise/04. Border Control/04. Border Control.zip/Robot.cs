﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Border_Control
{
    public class Robot:IRobots
    {
        public string Id { get; set; }

        public string Model { get; set; }

        public Robot(string model, string id)
        {
            this.Model = model;
            this.Id = id;
        }
    }
}
