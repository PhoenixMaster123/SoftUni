﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05._Birthday_Celebrations
{
    public interface IRobots
    {
        public string Model { get; }
        public string Id { get; }
    }
}
